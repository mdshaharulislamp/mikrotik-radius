from django.db import models
from Crypto.Hash import MD4
import subprocess


class CustRadUser(models.Model):
    fullname = models.CharField(max_length=64)
    employee_id = models.CharField(max_length=64, unique=True)
    Email_id = models.CharField(max_length=64, unique=True)
    department = models.CharField(max_length=64)
    username = models.CharField(max_length=64, unique=True)
    password = models.CharField(max_length=64)
    is_active = models.BooleanField(default=True)
    allowed_nasip = models.CharField(max_length=64, blank=True, null=True, verbose_name="Allowed Router", help_text="Specific IP for Partner (e.g., 192.168.1.10). While this leave empty Router Group")
    mikrotik_group = models.ForeignKey('UsersGroup', on_delete=models.SET_NULL, null=True, verbose_name="Permission")

    calling_station_ids = models.CharField(blank=True,help_text="Multiple IP comma seperated (e.g., 192.168.1.10,192.168.1.11)", max_length=64, verbose_name="Allowed IP's")
    
    nas_group = models.ForeignKey('NasGroup', on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Router Group")

    class Meta:
        verbose_name = "Radius User"
        db_table = 'custraduser'
        managed = False
        
    def save(self, *args, **kwargs):
        if self.password and not (len(self.password) == 32 and all(c in '0123456789ABCDEF' for c in self.password.upper())):
            h = MD4.new()
            h.update(self.password.encode('utf-16le'))
            self.password = h.hexdigest().upper()
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f'{self.fullname}'

class UsersGroup(models.Model):
    id = models.AutoField(primary_key=True)
    group_name = models.CharField(max_length=60)

    class Meta:
        verbose_name = "User Group"
        db_table = 'users_group'
        managed = False
    def __str__(self):
        return self.group_name
    
class NasGroup(models.Model):
    id = models.AutoField(primary_key=True)
    group_name = models.CharField(max_length=60)

    class Meta:
        verbose_name = "Router Group"
        db_table = 'nas_group'
        managed = False

    def __str__(self):
        return f'{self.group_name}'

class Nas(models.Model):
    identity = models.CharField(max_length=64, blank=True, null=True)
    nasname = models.GenericIPAddressField(unique=True, verbose_name="NAS IP")
    shortname = models.CharField(max_length=32)
    type = models.CharField(max_length=30, default='other')
    secret = models.CharField(max_length=60)
    nas_group = models.ForeignKey(NasGroup, on_delete=models.SET_NULL, null=True)
    class Meta:
        verbose_name = "Device"
        db_table = 'nas'
        managed = False

    def __str__(self):
        return f'{self.identity}'
        
class RadAcct(models.Model):
    radacctid = models.BigAutoField(primary_key=True)
    acctsessionid = models.CharField(max_length=64)
    acctuniqueid = models.CharField(max_length=32, unique=True)
    username = models.CharField(max_length=64, blank=True, null=True)
    realm = models.CharField(max_length=64, blank=True, null=True)
    nasipaddress = models.GenericIPAddressField()
    nasportid = models.CharField(max_length=15, blank=True, null=True)
    nasporttype = models.CharField(max_length=32, blank=True, null=True)
    acctstarttime = models.DateTimeField(blank=True, null=True)
    acctstoptime = models.DateTimeField(blank=True, null=True)
    acctsessiontime = models.IntegerField(blank=True, null=True)
    acctauthentic = models.CharField(max_length=32, blank=True, null=True)
    acctinputoctets = models.BigIntegerField(blank=True, null=True)
    acctoutputoctets = models.BigIntegerField(blank=True, null=True)
    calledstationid = models.CharField(max_length=50, blank=True, null=True)
    callingstationid = models.CharField(max_length=50, blank=True, null=True)
    acctterminatecause = models.CharField(max_length=32, blank=True, null=True)
    servicetype = models.CharField(max_length=32, blank=True, null=True)
    framedprotocol = models.CharField(max_length=32, blank=True, null=True)
    framedipaddress = models.GenericIPAddressField(blank=True, null=True)

    def __str__(self):
        return f"{self.username} - {self.acctsessionid}"

    class Meta:
        verbose_name = "Users Session"
        db_table = 'radacct'
        managed = False

class RadPostAuth(models.Model):
    username = models.CharField(max_length=64)
    pass_field = models.CharField("Password", db_column='pass', max_length=64)
    reply = models.CharField(max_length=32)
    authdate = models.DateTimeField()
    callingstationid = models.CharField(max_length=50, blank=True, null=True)
    nasipaddress = models.CharField(max_length=45, blank=True, null=True)

    def __str__(self):
        return f"{self.username} - {self.reply} @ {self.authdate}"
    
    class Meta:
        verbose_name = "Authentication Log"
        db_table = 'radpostauth'
        managed = False
