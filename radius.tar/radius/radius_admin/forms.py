from django import forms
from .models import *
from django.db import transaction
import hashlib

class NasGroupForm(forms.ModelForm):
    class Meta:
        model = NasGroup
        fields = '__all__'

class UsersGroupForm(forms.ModelForm):
    class Meta:
        model = UsersGroup
        fields = '__all__'

class CustRadUserForm(forms.ModelForm):
    password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(render_value=False),
        help_text="Leave blank if you don't want to change the password."
    )

    class Meta:
        model = CustRadUser
        fields = '__all__'

    def clean_password(self):
        password = self.cleaned_data.get('password')
        if password:
            #import hashlib
            #password = hashlib.new('md4', password.encode('utf-16le')).hexdigest().upper()
            # Return the raw password (or hash if you want) to be saved in RadCheck
            return password
        else:
            # Keep existing password unchanged
            # Must fetch existing password from instance or RadCheck table if stored there
            # Assuming here password field on instance has current password string
            return self.instance.password

    def save(self, commit=True):
        user = super().save(commit=False)
        return user
