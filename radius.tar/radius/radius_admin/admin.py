from django.contrib import admin
from .models import *
from .forms import *  # import the form you just created

#@admin.register(RadiusUser)
#class RadiusUserAdmin(admin.ModelAdmin):
#    form = RadiusUserForm
#    list_display = ('username', 'fullname', 'employee_id', 'department', 'is_active')
#   search_fields = ('username', 'employee_id', 'Email_id')

@admin.register(NasGroup)
class NasGroupAdmin(admin.ModelAdmin):
    form = NasGroupForm
    list_display = ('id','group_name')

@admin.register(UsersGroup)
class UsersGroupAdmin(admin.ModelAdmin):
    form = UsersGroupForm
    list_display = ('id','group_name')

@admin.register(CustRadUser)
class CustRadUserAdmin(admin.ModelAdmin):
    form = CustRadUserForm
    list_display = ('username', 'password', 'fullname', 'employee_id', 'department', 'is_active', 'nas_group')
    search_fields = ('username', 'employee_id', 'Email_id')

@admin.register(Nas)
class NasAdmin(admin.ModelAdmin):
    list_display = ('identity','nasname', 'shortname', 'type', 'nas_group')

#@admin.register(RadCheck)
#class RadCheckAdmin(admin.ModelAdmin):
#    form = RadCheckForm
#    list_display = ('username', 'attribute', 'value')
#    search_fields = ('username',)

#    def delete_model(self, request, obj):
#        RadReply.objects.filter(username=obj.username).delete()
#        RadCheck.objects.filter(username=obj.username).delete()

@admin.register(RadPostAuth)
class RadPostAuthAdmin(admin.ModelAdmin):
    list_display = ('username', 'pass_field', 'reply', 'authdate', 'nasipaddress', 'callingstationid')

@admin.register(RadAcct)
class RadAcctAdmin(admin.ModelAdmin):
    list_display = ('username', 'nasipaddress', 'acctstarttime', 'acctstoptime')
    search_fields = ('username',)

