from django.apps import AppConfig


class RadiusAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'radius_admin'
    verbose_name = "Radius Admin"